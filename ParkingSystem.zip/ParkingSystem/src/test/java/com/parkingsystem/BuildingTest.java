package com.parkingsystem;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class BuildingTest {
	Building building;
	@Before
	public void setup() {
		building = new Building(6, 20);
	}
	
	@Test
	public void testGetOpenSlots() {
		assertEquals(building.getOpenSpots(), 120);
	}
	
	@Test
	public void testGetOpenSlotReturnsFreeSlot() {
		Slot slot = building.getFreeSpot();
		assertNotNull(slot.getFloor());
		assertTrue(slot.getSlotNumber() > 0);
		Slot expectedSlot = building.getFloor(slot.getFloor().getLevel()).getSlot(slot.getSlotNumber());
		assertEquals(slot, expectedSlot);
	}
	
	@Test
	public void testReserveSlot() {
		Slot slot = building.getFreeSpot();
		int openSpots = building.getOpenSpots();
		slot.reserve();
		Slot expectedSlot = building.getFloor(slot.getFloor().getLevel()).getSlot(slot.getSlotNumber());
		assertTrue(expectedSlot.getIsInUse());
		if(expectedSlot.getIsInUse()) {
			openSpots = openSpots+1;
		}
		assertEquals(building.getOpenSpots(), openSpots-1);
	}

}
