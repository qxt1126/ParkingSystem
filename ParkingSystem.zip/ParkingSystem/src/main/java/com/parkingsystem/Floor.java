package com.parkingsystem;

import java.util.ArrayList;
import java.util.List;

public class Floor {
	private int slotCount;
	private int floorLevel;
	List<Slot> slots = new ArrayList<Slot>();
	
	public Floor(int slotCount, int floorLevel) {
		this.slotCount = slotCount;
		this.floorLevel = floorLevel;
		for(int i=0;i<slotCount; i++) {
			slots.add(new Slot(this, i));
		}
	}

	public int getSlotCount() {
		return slotCount;
	}

	public void setSlotCount(int slot) {
		this.slotCount = slot;
	}
	
	public int getLevel() {
		return this.floorLevel;
	}
	
	public Slot getSlot(int slotNumber) {
		return slots.get(slotNumber);
	}
	
}
