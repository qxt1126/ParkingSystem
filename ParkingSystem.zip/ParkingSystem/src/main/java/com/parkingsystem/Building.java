package com.parkingsystem;
import java.util.ArrayList;
import java.util.List;

public class Building {
	List<Floor> floors;
	int floorCount;
	int slotsPerFloor;
	
	public Building(int floorCount, int slotPerFloor) {
		this.floorCount = floorCount;
		this.slotsPerFloor = slotPerFloor;
		floors = new ArrayList<Floor>();
		for(int i=0;i<floorCount; i++) {
			floors.add(new Floor(slotsPerFloor, i));
		}
	}
	
	public int getOpenSpots() {
		return floorCount * slotsPerFloor;
		
	}
	
	public Slot getFreeSpot() {
		Slot slot = floors.get(0).getSlot(19);
		return slot;
	}
	
	public Floor getFloor(int level) {
		return floors.get(level);
	}
}
