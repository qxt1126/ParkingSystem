package com.parkingsystem;

public class Slot {
	
	private int slotNumber;
	private boolean isInUse = false;
	private Floor floor;
	
	public Slot(Floor floor, int slotNumber) {
		this.slotNumber = slotNumber;
		this.floor = floor;
	}
	
	public Floor getFloor() {
		return this.floor;
	}
	
	public int getSlotNumber() {
		return this.slotNumber;
	}
	
	public void reserve() {
		if(!isInUse) {
			isInUse = true;
			
			return;
		}
		throw new RuntimeException();
	}
	
	public boolean getIsInUse() {
		return isInUse;
	}
}
